<?php namespace App\Events\User;

use App\Events\Event;

class LogoutEvent extends Event
{
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct() {

        //

    }
}
