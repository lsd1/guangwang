var __reflect = (this && this.__reflect) || function (p, c, t) {
    p.__class__ = c, t ? t.push(c) : t = [c], p.__types__ = p.__types__ ? t.concat(p.__types__) : t;
};
var __extends = this && this.__extends || function __extends(t, e) { 
 function r() { 
 this.constructor = t;
}
for (var i in e) e.hasOwnProperty(i) && (t[i] = e[i]);
r.prototype = e.prototype, t.prototype = new r();
};
var MyGarden = (function (_super) {
    __extends(MyGarden, _super);
    function MyGarden() {
        var _this = _super.call(this) || this;
        _this.common = Common.Shared();
        //是否‘提示框’打开的遮罩
        _this.is_tips_mask = false;
        _this.skinName = "resource/garden_skins/MyGarden.exml";
        _this.right = 0;
        _this.left = 0;
        _this.top = 0;
        _this.bottom = 0;
        //获取果园信息
        var httpReq = new HttpReq();
        var url = 'v1.0/user/show_garden';
        httpReq.GET({
            url: url,
            data: {},
            success: function (res) {
                var res = JSON.parse(res);
                if (res.code == 0) {
                    console.log(res);
                }
            },
            error: function () {
                console.log('error');
            },
            progress: function () {
                console.log('waiting......');
            }
        });
        //关闭提示弹框
        _this.tips_close.addEventListener(egret.TouchEvent.TOUCH_TAP, function () {
            if (_this.is_tips_mask) {
                _this.full_mask.visible = false;
            }
            _this.group_tips.visible = false;
        }, _this);
        //道具列表
        _this.props.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onPropsTap, _this);
        _this.props_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onPropsCloseTap, _this);
        _this.interaction.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onInteractionTap, _this);
        //道具使用提示
        _this.tool_tips_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onToolTipsCloseTap, _this);
        _this.commit_tool_tips.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onCommitToolTipsTap, _this);
        //激活套餐
        _this.active_package_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onActivePackageCloseTap, _this);
        //我的果园
        _this.manage.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onManageTap, _this);
        _this.garden_interactive_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onGardenInteractiveCloseTap, _this);
        _this.garden_news_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onGardenNewsCloseTap, _this);
        _this.garden_manger_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onGardenMangerCloseTap, _this);
        //修改密码
        _this.change_password.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onChangePasswordTap, _this);
        _this.set_pass_word_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onSetPassWordCloseTap, _this);
        _this.commit_change.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onCommitChangeTap, _this);
        _this.old_pass_word.addEventListener(egret.FocusEvent.FOCUS_IN, _this.onInputFocus, _this);
        //提取积分
        _this.extract_point.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onExtractPointTap, _this);
        _this.extract_point_close.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onExtractPointCloseTap, _this);
        _this.commit_extract_point.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onCommitExtractPointTap, _this);
        //修改头像
        _this.change_avatar.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onChangeAvatarTap, _this);
        //this.commit_extract_point.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onCommitExtractPointTap, this);
        _this.cut_area.addEventListener(egret.TouchEvent.TOUCH_BEGIN, _this.onCutAreaBegin, _this);
        _this.cut_area.addEventListener(egret.TouchEvent.TOUCH_MOVE, _this.onCutAreaMove, _this);
        _this.cut_area.addEventListener(egret.TouchEvent.TOUCH_END, _this.onCutAreaEnd, _this);
        _this.cut_area.addEventListener(egret.TouchEvent.TOUCH_RELEASE_OUTSIDE, _this.onCutAreaEnd, _this);
        _this.cut_commit.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onCutCommitTap, _this);
        //顶部果园用户头像、昵称信息
        _this.my_avatar.source = _this.common.getCookie('avatar');
        _this.user_name.text = _this.common.getCookie('username');
        var topAvatar = _this.common.createCircleMask(100, 100, _this.common.getCookie('avatar'), 20, 20);
        var topAvatarBg = _this.common.createImage(350, 140, "garden_data_bg_png", 0, 0);
        var label = new eui.Label();
        label.width = 380;
        label.height = 140;
        label.textAlign = "center";
        label.verticalAlign = "middle";
        label.size = 30;
        label.text = _this.common.getCookie('username');
        label.textColor = 0x000000;
        _this.group_top.addChild(topAvatarBg);
        _this.group_top.addChild(topAvatar);
        _this.group_top.addChild(label);
        //横线
        var line = new egret.Shape();
        line.graphics.lineStyle(2, 0x000000, 0.1);
        line.graphics.moveTo(750, -30);
        line.graphics.lineTo(0, -30);
        line.graphics.endFill();
        _this.group_avatar.addChild(line);
        //尾部果园互动消息列表
        for (var i = 0; i < 6; i++) {
            var avatar = new AvatarList();
            avatar.x = 25 + i * 120;
            if (i == 5) {
                _this.garden_more_news = avatar.createAvatar(i + 1, "mygarden_png", "30");
                _this.group_avatar.addChild(_this.garden_more_news);
            }
            else {
                var avatar_cell = avatar.createAvatar(i + 1, "mygarden_png", "30");
                _this.group_avatar.addChild(avatar_cell);
            }
        }
        _this.garden_more_news.addEventListener(egret.TouchEvent.TOUCH_TAP, _this.onGardenMoreNewsTap, _this);
        return _this;
    }
    MyGarden.Shared = function () {
        if (this.shared == null) {
            this.shared = new MyGarden();
        }
        return this.shared;
    };
    //点击道具
    MyGarden.prototype.onPropsTap = function (e) {
        var _this = this;
        this.full_mask.visible = true;
        var httpReq = new HttpReq();
        var url = 'v1.0/tool/show';
        httpReq.GET({
            url: url,
            data: {},
            success: function (res) {
                var res = JSON.parse(res);
                if (res.code == 0) {
                    var toolList = res.data.toolList;
                    for (var i = 0; i < toolList.length; i++) {
                        var toolInfo = toolList[i];
                        var myTool = new Tools();
                        if (i < 3) {
                            myTool.x = 21 + 180 * (i);
                            myTool.y = 93;
                        }
                        else {
                            myTool.x = 21 + 180 * (i - 3);
                            myTool.y = 93 + 209;
                        }
                        switch (toolInfo.toolId) {
                            case 1:
                                myTool.tool_img.source = 'props_icon01_png';
                                break;
                            case 2:
                                myTool.tool_img.source = 'props_icon02_png';
                                break;
                            case 3:
                                myTool.tool_img.source = 'props_icon03_png';
                                break;
                            case 4:
                                myTool.tool_img.source = 'props_icon04_png';
                                break;
                            case 5:
                                myTool.tool_img.source = 'props_icon05_png';
                                break;
                        }
                        myTool.tool_num.text = toolInfo.count;
                        myTool.tool_name.text = toolInfo.toolname;
                        myTool.tool_id = toolInfo.toolId;
                        _this.panel_props.addChild(myTool);
                    }
                    _this.panel_props.visible = true;
                }
                else {
                    _this.tips_text = res.msg;
                    _this.group_tips.visible = true;
                }
            },
            error: function () {
                console.log('error');
            },
            progress: function () {
                console.log('waiting......');
            }
        });
    };
    //点击互动
    MyGarden.prototype.onInteractionTap = function (e) {
        var _this = this;
        var httpReq = new HttpReq();
        var url = 'v1.0/user/pick_list';
        httpReq.GET({
            url: url,
            data: {},
            success: function (res) {
                var res = JSON.parse(res);
                console.log(res);
                if (res.code == 0) {
                    var pickList = res.data.pickList;
                    console.log(pickList);
                    for (var i = 0; i < pickList.length; i++) {
                        var interaction = new InteractionList(pickList[i].id, pickList[i].username);
                        var typeArr = [];
                        if (pickList[i].countdown > 0) {
                            typeArr.push(3);
                            var list = interaction.createList('https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=188103899,3971327013&fm=27&gp=0.jpg', pickList[i].username, typeArr, [pickList[i].countdown], 0, i * 122);
                        }
                        else {
                            pickList[i].isMature > 0 ? typeArr.push(2) : null;
                            pickList[i].isWater > 0 ? typeArr.push(1) : null;
                            //var list = interaction.createList(pickList[i].avatar, pickList[i].username, typeArr, [], 0, i * 122);
                            var list = interaction.createList('https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=188103899,3971327013&fm=27&gp=0.jpg', pickList[i].username, typeArr, [], 0, i * 122);
                        }
                        _this.group_interactive_list.addChild(list);
                    }
                }
            },
            error: function () {
                console.log('error');
            },
            progress: function () {
                console.log('waiting......');
            }
        });
        this.panel_garden_interactive.visible = true;
    };
    //点击管理
    MyGarden.prototype.onManageTap = function (e) {
        var _this = this;
        var httpReq = new HttpReq();
        var url = 'v1.0/user/score_logs';
        httpReq.GET({
            url: url,
            data: {},
            success: function (res) {
                var res = JSON.parse(res);
                if (res.code == 0) {
                    var scoreLogList = res.data.scoreLogList;
                    for (var i = 0; i < scoreLogList.length; i++) {
                        var score_log = new ScoreList(10, 10 + 40 * i);
                        score_log.score_desc.text = scoreLogList[i].content;
                        score_log.score_change.text = scoreLogList[i].changeScore;
                        score_log.score_date.text = scoreLogList[i].datetime;
                        _this.group_point_list.addChild(score_log);
                    }
                }
            },
            error: function () {
                console.log('error');
            },
            progress: function () {
                console.log('waiting......');
            }
        });
        this.panel_garden_manger.visible = true;
    };
    //关闭我的果园弹框
    MyGarden.prototype.onGardenMangerCloseTap = function (e) {
        this.full_mask.visible = false;
        this.panel_garden_manger.visible = false;
    };
    //关闭道具弹框
    MyGarden.prototype.onPropsCloseTap = function (e) {
        this.full_mask.visible = false;
        this.panel_props.visible = false;
    };
    //关闭果园互动
    MyGarden.prototype.onGardenInteractiveCloseTap = function (e) {
        this.panel_garden_interactive.visible = false;
    };
    //关闭果园动态
    MyGarden.prototype.onGardenNewsCloseTap = function (e) {
        this.panel_garden_news.visible = false;
    };
    //关闭套餐激活弹框
    MyGarden.prototype.onActivePackageCloseTap = function (e) {
        this.full_mask.visible = false;
        this.panel_active_package.visible = false;
    };
    //提交套餐激活弹框
    MyGarden.prototype.onCommitActivePackageTap = function (e) {
        this.panel_active_package.visible = false;
        var data = { "number": 999, "price": 10, "payOrder": "mcoinTrade" };
        console.log(data);
        //window.maiguoer.buyCoinToPay(JSON.stringify(data));
    };
    //弹出果园动态框
    MyGarden.prototype.onGardenMoreNewsTap = function (e) {
        for (var i = 0; i < 17; i++) {
            var news = new NewsList();
            if (i == 0) {
                var list = news.createList('mygarden_png', '曲终人散', 3600, 0, i * 122);
            }
            else if (i < 2 && i > 0) {
                var list = news.createList('mygarden_png', '曲终人散', 3500, 0, i * 122);
            }
            else {
                var list = news.createList('mygarden_png', '曲终人散', 3400, 0, i * 122);
            }
            this.group_news_list.addChild(list);
        }
        this.panel_garden_news.visible = true;
    };
    MyGarden.prototype.onChangePasswordTap = function (e) {
        this.full_mask.visible = true;
        this.panel_set_pass_word.visible = true;
    };
    MyGarden.prototype.onSetPassWordCloseTap = function (e) {
        this.full_mask.visible = false;
        this.panel_set_pass_word.visible = false;
    };
    //修改密码-提交
    MyGarden.prototype.onCommitChangeTap = function (e) {
        var _this = this;
        if (this.old_pass_word.text == '') {
            this.tips_text.text = '请输入原来的密码！';
            this.group_tips.visible = true;
            return false;
        }
        if (this.old_pass_word.text == '') {
            this.tips_text.text = '请输入新密码！';
            this.group_tips.visible = true;
            return false;
        }
        if (this.old_pass_word.text == '') {
            this.tips_text.text = '请再次输入新密码！';
            this.group_tips.visible = true;
            return false;
        }
        if (this.new_pass_word.text !== this.repeat_pass_word.text) {
            this.tips_text.text = '两次输入密码不一致！';
            this.group_tips.visible = true;
            return false;
        }
        else {
            var httpReq = new HttpReq();
            var url = 'v1.0/user/edit_password';
            httpReq.POST({
                url: url,
                data: { oldpassword: this.old_pass_word.text, newpassword: this.new_pass_word.text },
                success: function (res) {
                    var res = JSON.parse(res);
                    if (res.code == 0) {
                        _this.tips_text.text = '修改密码成功';
                        _this.group_tips.visible = true;
                    }
                    else {
                        _this.tips_text.text = res.msg;
                        _this.group_tips.visible = true;
                    }
                },
                error: function () {
                    console.log('error');
                },
                progress: function () {
                    console.log('waiting......');
                }
            });
        }
    };
    MyGarden.prototype.onExtractPointTap = function (e) {
        this.full_mask.visible = true;
        this.panel_extract_point.visible = true;
    };
    MyGarden.prototype.onExtractPointCloseTap = function (e) {
        this.full_mask.visible = false;
        this.panel_extract_point.visible = false;
    };
    //提取积分
    MyGarden.prototype.onCommitExtractPointTap = function (e) {
        var _this = this;
        var httpReq = new HttpReq();
        var url = 'v1.0/user/draw_score';
        var score = this.point_number.text;
        var address = this.wallet_address.text;
        if (parseInt(score) <= 0 || score == '') {
            this.tips_text.text = '请输入正确的积分数目';
            this.group_tips.visible = true;
            return false;
        }
        if (address == '') {
            this.tips_text.text = '钱包地址不能为空';
            this.group_tips.visible = true;
            return false;
        }
        console.log(score, '-', address);
        httpReq.POST({
            url: url,
            data: { score: score, address: address },
            success: function (res) {
                var res = JSON.parse(res);
                if (res.code == 0) {
                    _this.tips_text.text = '积分提取成功';
                    _this.group_tips.visible = true;
                }
                else {
                    _this.tips_text.text = res.msg;
                    _this.group_tips.visible = true;
                }
            },
            error: function () {
                console.log('error');
            },
            progress: function () {
                console.log('waiting......');
            }
        });
        this.panel_extract_point.visible = false;
    };
    MyGarden.prototype.onInputFocus = function (e) {
        console.log(EventTarget);
    };
    //修改头像
    MyGarden.prototype.onChangeAvatarTap = function (e) {
        selectImage(this.selImg, this);
    };
    MyGarden.prototype.selImg = function (a, b, c) {
        a.origin_image.source = b;
        //裁剪区域范围，舞台上半部分
        a.cut_area_group.width = a.stage.stageWidth;
        a.cut_area_group.height = a.stage.stageHeight / 2;
        //新图片的呈现区域范围，舞台下半部分
        a.new_area_group.y = a.stage.stageHeight / 2;
        a.new_area_group.width = a.stage.stageWidth;
        a.new_area_group.height = a.stage.stageHeight / 2;
        a.origin_image.addEventListener(egret.Event.COMPLETE, function () {
            //舞台和原始图片的宽高比
            var stage_aspect_ratio = a.stage.stageWidth / a.stage.stageHeight;
            var image_aspect_ratio = a.origin_image.width / a.origin_image.height;
            //计算原始图片宽高比和舞台宽高比，然后等比缩放图片到舞台。
            if (image_aspect_ratio > stage_aspect_ratio) {
                a.origin_image.width = a.stage.stageWidth / 2;
                a.origin_image.height = a.stage.stageWidth / image_aspect_ratio / 2;
            }
            else {
                a.origin_image.height = a.stage.stageHeight / 2;
                a.origin_image.width = a.stage.stageHeight * image_aspect_ratio / 2;
            }
            //裁剪区域为正方形。
            a.cut_area.width = a.cut_area.height = a.origin_image.height < a.origin_image.width ? a.origin_image.height : a.origin_image.width;
            console.log(a.stage.stageWidth, '-', a.stageHeight);
            a.cut_area.x = a.stage.stageWidth / 2 - (a.cut_area.width / 2);
            a.cut_area.y = 0;
            a.setImageTexture(a.new_image);
            a.cut_image.visible = true;
            a.full_mask.fillAlpha = 1;
            a.full_mask.visible = true;
        }, a);
        // var mydisp:any = b;
        // var rt: egret.RenderTexture = new egret.RenderTexture();   //建立缓冲画布
        // rt.drawToTexture(mydisp, new egret.Rectangle(0, 0, mydisp.width, mydisp.height));  //将对象画到缓冲画布上（可指定画对象的某个区域，或画整个）
        // this.my_avatar.texture = rt;
        // var imageBase64:string = rt.toDataURL("image/png");  //转换为图片base64。  （对的你没看错！就这么3行。。。。）
        // console.log(imageBase64); //弹出来看看
        // var saveImage: HTMLImageElement = new Image;
        // saveImage.onload = () => {   //图片加载完成事件（只有加载完成才能转换）
        // 	saveImage.onload = null;
        // 	var myBmp:egret.Bitmap = new egret.Bitmap(<any>saveImage);   //将image强转为egret.Texture即可，也可以将HTMLCanvasElement强转为egret.Texture
        // 	this.addChild(myBmp);   //假设有一个容器叫myContainer，将建立的egret.Bitmap添加到容器
        // }
        // saveImage.src = imageBase64;  //使用上面生成的base64字符串开始加载图片
    };
    MyGarden.prototype.onCutAreaBegin = function (e) {
        this.startX = e.localX;
        this.startY = e.localY;
    };
    MyGarden.prototype.onCutAreaMove = function (e) {
        var stepX = e.localX - this.startX;
        var stepY = e.localY - this.startY;
        var minX = this.origin_image.x;
        var maxX = this.origin_image.width + this.origin_image.x - this.cut_area.width;
        var minY = this.origin_image.y;
        var maxY = this.origin_image.height + this.origin_image.y - this.cut_area.height;
        var nowX = this.cut_area.x + stepX;
        var nowY = this.cut_area.y + stepY;
        //移动裁剪区域时，裁剪区域不能超过图片区域。
        nowX = nowX > maxX ? maxX : nowX;
        nowX = nowX < minX ? minX : nowX;
        nowY = nowY > maxY ? maxY : nowY;
        nowY = nowY < minY ? minY : nowY;
        this.cut_area.x = nowX;
        this.cut_area.y = nowY;
        this.startX = e.localX;
        this.startY = e.localY;
    };
    MyGarden.prototype.onCutAreaEnd = function (e) {
        //停止移动时把裁剪区域更新到新图片区域
        this.setImageTexture(this.new_image);
    };
    MyGarden.prototype.onCutCommitTap = function (e) {
        //确定裁剪之后，更新头像。
        this.setImageTexture(this.my_avatar);
        this.cut_image.visible = false;
        this.full_mask.fillAlpha = 0.4;
        this.full_mask.visible = false;
    };
    MyGarden.prototype.setImageTexture = function (image) {
        var rt = new egret.RenderTexture;
        rt.drawToTexture(this.origin_image, new egret.Rectangle(this.cut_area.x - this.origin_image.x, this.cut_area.y - this.origin_image.y, this.cut_area.width, this.cut_area.height), 1);
        image.texture = rt;
    };
    MyGarden.prototype.onToolTipsCloseTap = function (e) {
        this.full_mask.visible = false;
        this.panel_tool_tips.visible = false;
    };
    MyGarden.prototype.onCommitToolTipsTap = function (e) {
        console.log(this.useToolGroup.tool_num.text);
        console.log(this.useToolGroup.tool_id);
        this.useToolGroup.tool_num.text--;
        this.panel_tool_tips.visible = false;
    };
    return MyGarden;
}(eui.Component));
__reflect(MyGarden.prototype, "MyGarden");
//# sourceMappingURL=MyGarden.js.map