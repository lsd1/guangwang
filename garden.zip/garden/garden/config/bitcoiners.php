<?php

return [

	'default' => 'easyblockchain',

	'coiners' => [
		
		'easyblockchain' => [
			
			'driver' => 'easyblockchain',

			'host' => '127.0.0.1',

			'port' => '22278',

			'user' => 'mubao',

			'password' => 'testmubao'

		],

	]

];
