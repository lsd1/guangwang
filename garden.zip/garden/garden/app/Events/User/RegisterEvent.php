<?php namespace App\Events\User;

use App\Events\Event;

class RegisterEvent extends Event
{
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct() {

        //

    }
}
