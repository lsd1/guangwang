class ActionParams{
	public url:string;
	public data:{};
	public success:any;
	public error:any;
	public progress:any;
}