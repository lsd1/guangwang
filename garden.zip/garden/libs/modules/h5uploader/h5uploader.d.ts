declare function selectImage(selectedHandler:Function,thisRef:any): void;
declare function selectImageWX(selectedHandler:Function,thisRef:any): void;
declare function getImageData(file:Blob,bytesHandler:Function,thisRef:any): void;
declare function isWeixin():boolean;