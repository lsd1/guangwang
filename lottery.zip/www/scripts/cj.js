var nametxt = $('.name'),
 phonetxt = $('.phone'),
 pcount = phone.length - 1,//参加人数
 running = true,//抽奖状态
 num,
 zd = {"1":{"name":"一等奖","num":[13613040019]},"2":{"name":"二等奖","num":[13613040012,13613040017]},"3":{"name":"二等奖","num":[13613040013,13613040018]},"4":[]},//指定
 t,//定时器
 phone = [],//抽奖列表
 zd_key,//
 count = 1;
function action(){
    if(running){
        start()
    }else{
        stop();
    }
}
//开始停止
function start() {
    if(td<1){
        alert("请设置抽奖人数");
        return;
    }
    if (phone.length > 2) {
        pcount = phone.length - 1;
    }else{
        alert("待抽奖号码太少了");
        return;
    }

    if(td<=0){
        alert("奖项已抽取完毕");
        return;
    }

    running = false;
    $('#btntxt').removeClass('start').addClass('stop');
    $('#btntxt').html('停止');
    that.socket.emit('start');
    startNum();
    $('#sound_play')[0].play();
}
//循环参加名单
function startNum() {
	num = Math.floor(Math.random() * (phone.length-1));
    var target = phone[num];
    if (target == undefined) {
        startNum()
    }
    phonetxt.html(target);
    t = setTimeout(startNum, 100);
}
//停止跳动
function stop() {
	that.socket.emit('stop',td,phonenum);
}

//打印中奖者名单
function show() {
	clearInterval(t);
    t = 0;
    phonetxt.html(phonenum);
    running = true;
    $('#btntxt').removeClass('stop').addClass('start');
    $('#btntxt').html('开始');
    $('.list').prepend("<p>" + lottery_type + ":" + phonenum + "</p>");
    that.socket.emit('getList',$('.list').html());
    var result = phone.join("\n");
    $("textarea").val("").val(result);
    if (pcount <= 0 || td <= 0) {
        setTimeout(function(){
            alert("开奖结束");
        },1000);
        pcount = new Array();
    }
}
//按中奖顺序指定
/*function zj(){
	num_true = Math.floor(Math.random() * (phone.length-1));
    if(zd_key[phone[num_true]]){
        if(count<zd_key[phone[num_true]]){
          zj();  
        }
    }
    if(zd[count] && phone.indexOf(zd[count]) != -1){
        num_true = phone.indexOf(zd[count]);
        zd[count] = undefined;
    }
	clearInterval(t);
    t = 0;
	num = num_true;
	phonetxt.html(phone[num]);
}
function zj(){
    num = Math.floor(Math.random() * (phone.length-1));
    if(zd[lottery_type].length>0){//如果对应的zd有值，那么去求交集
        var intersection_zd = [];//交集
        for(i in zd[lottery_type]){
           if(rever_phone[zd[lottery_type][i]]){
               intersection_zd.push(zd[lottery_type][i]);
               rever_phone[zd[lottery_type][i]] = undefined;
           }
        }

        if(intersection_zd.length>0){//如果有交集，从交集中抽取。
           var zd_num = Math.floor(Math.random() * (intersection_zd.length-1));
           num = phone.indexOf(intersection_zd[zd_num].toString());
        }
    }
    clearInterval(t);
    t = 0;
    phonetxt.html(phone[num]);
}*/

//js 读取文件
function jsReadFiles(files) {
	if (files.length) {
		var file = files[0];
		var reader = new FileReader();//new一个FileReader实例
		if (/text+/.test(file.type)) {//判断文件类型，是不是text类型
			reader.onload = function() {
				console.log(typeof this.result);
				//$('body').append('<pre>' + this.result + '</pre>');
			}
			reader.readAsText(file);
		} else if(/image+/.test(file.type)) {//判断文件是不是imgage类型
			reader.onload = function() {
				console.log(this.result);
				$('body').append('<img src="' + this.result + '"/>');
			}
			reader.readAsDataURL(file);
		}
	}
}
