var nametxt = $('.name'),
 phonetxt = $('.phone'),
 running = true,
 num,
 t,//定时器
 counts;

//开始停止
function start() {
    if(running == false ){
        return false;
    }
    running = false;
    startNum();
    $('#sound_play')[0].play();
}
//循环参加名单
function startNum() {
	num = Math.floor(Math.random() * (phone.length-1));
    var target = phone[num];
    if (target == undefined) {
        startNum();
    }
    phonetxt.html(target);
    t = setTimeout(startNum, 0);
}
//停止跳动,打印中奖者名单
function show() {
	running = true;
    clearInterval(t);
    t = 0;
	phonetxt.html(phonenum);
    $('.list').prepend("<p>" + lottery_type + ":" + phonenum + "</p>");
	if(td  <= 0){
		setTimeout(function(){
            alert("开奖结束");
        },1000);
	}
}
//查询抽奖概率。
function search(){
    var maiguo_num = $('#maiguo_num').val();
    var allcounts = phone.length;
    for(i in phone){
        if(phone[i] == maiguo_num){
            counts++;
        }
    }
    alert(Math.floor(counts*100/allcounts*100)/100+'%');
    counts = 0;
}

