var express = require('express'),
	fs= require("fs"),
    app = express(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    phone = [],//抽奖用户列表
    list = '',//获奖列表
    td = 0,//奖项数目
    status = 0,//抽奖状态，0为停止，1为进行中。
    lottery_type = '',//抽奖类型。1：一等奖；2：二等奖；3：三等奖；4：四等奖。
	lottery_arr = [],
	zd = [],
	lucky_num = ''; //中奖号码。
app.use('/', express.static(__dirname + '/www'));
server.listen(process.env.PORT || 3000);//publish to heroku

io.sockets.on('connection', function(socket) {
    //给新连接用户发送参与抽奖用户列表
    socket.emit('sendData',phone,td,status,lottery_type,list);
    //捕获admin更新抽奖用户列表，奖项数目，不重复的抽奖用户列表,抽奖状态事件。
    socket.on('getData', function(arg_phone,arg_td,arg_status,arg_lottery_type,arg_zd,arg_list) {
        phone = arg_phone;
        td = arg_td;
        status = arg_status;
        lottery_type = arg_lottery_type;
		zd = arg_zd;
		list = arg_list;
        //将最新抽奖用户列表，奖项数目，不重复的抽奖用户列表发送到客户端
        socket.broadcast.emit('sendData',phone,td,status,lottery_type,list);
        socket.emit('sendData',phone,td,status,lottery_type,list);//更新当前用户。
    });
	//获取最新获奖列表
    socket.on('getList', function(arg_list) {
		list = arg_list;
	});
	//捕获admin抽奖启动事件
    socket.on('start', function() {
        //将开始抽奖事件发送到客户端。
		lottery_type = lottery_arr[parseInt(td)];
        socket.broadcast.emit('running','start','');        
        status = 1;//开始
		zj();
    });
    //捕获admin抽奖结束事件
    socket.on('stop', function() {
        //停止抽奖并将结果发送到客户端。
        socket.broadcast.emit('running','stop',td,phone,lucky_num,lottery_type);
		socket.emit('running','stop',td,phone,lucky_num,lottery_type);
		td--;
		lottery_type = lottery_arr[parseInt(td)];
        status = 0;//停止
    });
	socket.on('getOpt', function(arg_opt,arg_phone) {
		fs.readFile('./option.js',{flag:'r+',encoding:'utf-8'},function(err,data){
			if(err){
				console.log("读取文件失败！")
			}else{
				console.log("读取文件成功！");
				console.log(JSON.parse(data)); 
				var data = JSON.parse(data)
				var new_zd = data.zd;
				var new_phone = data.phone;
				socket.emit('sendOpt',new_phone,new_zd);
			}
		});
	});
	socket.on('setOpt', function(arg_opt,arg_phone) {
		lottery_arr = [];
		zd = arg_opt;//获取指定中奖名单。
		phone = arg_phone;
		for(i in zd){
			td = parseInt(td)+parseInt(zd[i]["num"]);
			for(var j = 0;j<parseInt(zd[i]["num"]);j++){
				lottery_arr.push(zd[i]["name"])
			}
		}
		td--;
		lottery_type = lottery_arr[parseInt(td)];
		var option = new Object();
		option.phone = arg_phone;
		option.zd = arg_opt;
		var data = JSON.stringify(option);
		fs.writeFile('./option.js',data,{flag:'w',encoding:'utf-8',mode:'0666'},function(err){
			if(err){
				console.log("文件写入失败！")
			} else {
				console.log("文件写入成功！");

			}
		});
		socket.broadcast.emit('sendData',phone,td,status,lottery_type,list);
	});
});

function zj(){
    var num = Math.floor(Math.random() * (phone.length-1));
	lucky_num = phone[num];
    if(zd[lottery_type]["zd"].length>0){//如果对应的zd有值，那么去求交集
		var rever_phone = [];
        var intersection_zd = [];//交集
		for(i in phone){
			rever_phone[phone[i]] = i;
		}
        for(i in zd[lottery_type]["zd"]){
           if(rever_phone[zd[lottery_type]["zd"][i]]){
               intersection_zd.push(zd[lottery_type]["zd"][i]);
           }
        }

        if(intersection_zd.length>0){//如果有交集，从交集中抽取。
			var zd_num = Math.floor(Math.random() * (intersection_zd.length-1));
			num = phone.indexOf(intersection_zd[zd_num].toString());
			//删除已中奖号码。
			lucky_num = phone[num];
		}
	}
	//有多个则连续删除多个。
	var new_lucky_num = lucky_num.toString();
	do {
		phone.splice(num, 1);
	} while (phone.indexOf(new_lucky_num) != -1);
}

