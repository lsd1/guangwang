<?php

return [

        'ebcwallet' => [

                'password' => 'ebchhtzqcd',

                'fee' => 0.01

        ]

];
