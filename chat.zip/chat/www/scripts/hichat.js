/*
 *抽奖
 */
var status = 'stop';
var that;
var phone;
var td;
var unique_phone = [];
window.onload = function() {
    var hichat = new HiChat();
    hichat.init();
};
var HiChat = function() {
    this.socket = null;
};
HiChat.prototype = {
    init: function() {
        that = this;
        this.socket = io.connect();
        //获取抽奖名单
        this.socket.on('updatePhone', function(arg_phone,arg_td,arg_unique_phone) {
            phone = arg_phone;
            td = arg_td;
            unique_phone = arg_unique_phone;
            console.log(phone);
            console.log(td);
            console.log(unique_phone);
        });
        //刚联接上就更新获奖列表
        this.socket.on('updateList', function(arg_list) {
            if(arg_list){
                last_phone = arg_list.split("</p>")[0].split(' -- ')[1];
            }else{
                last_phone = '00000000000';
            }
            document.getElementById('last_phone').innerHTML = last_phone;
            document.getElementById('luck_list').innerHTML = arg_list;
        });
		this.socket.on('begin', function(arg_type,arg_td,arg_phonenum) {
			if(arg_type == 'start'){
                start();
            }else{
                start(arg_td,arg_phonenum);
            } 
        });
		//清空抽奖列表，重新开始。
		document.getElementById('btn_replay').addEventListener('click',function(){
            that.socket.emit('getPhone',[],0,[]);
            that.socket.emit('getList','');
        });
        //上传抽奖列表，重新开始。
        document.getElementById('btn_check').addEventListener('click',function(){
            var td = document.getElementById('count').value;
            var text = document.getElementById('userlist').value;
            if (text == "") return;
            var temp_text = text.split("\n");
            var target = new Array();
            for (var i = 0; i < temp_text.length; i++) {
                if (temp_text[i] != "") {
                    target.push(temp_text[i]);
                    unique_phone.push(i+'-'+temp_text[i]);
                }
            }
            console.log(unique_phone);
            that.socket.emit('getPhone',target,td,unique_phone);
        });
	}
};
