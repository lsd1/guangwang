var nametxt = $('.name');
var phonetxt = $('.phone');
var running = true;
var num;
var t;//定时器
var pcount;//参加人数
var counts = 0;//抽奖出现次数

//开始停止
function start() {
    if(running == false ){
        return false;
    }
    running = false;
    startNum();
    $('#sound_play')[0].play();
}
//循环参加名单
function startNum() {
	num = Math.floor(Math.random() * (phone.length-1));
    var target = phone[num];
    if (target == undefined) {
        startNum();
    }
    phonetxt.html(target);
    t = setTimeout(startNum, 0);
}
//停止跳动
function stop() {
    running = true;
    clearInterval(t);
    t = 0;
	phonetxt.html(phonenum);
    show();
}

//打印中奖者名单
function show() {
    $('.list').prepend("<p>" + td + " -- " + phonenum + "</p>");
}
//查询抽奖概率。
function search(){
    var maiguo_num = $('#maiguo_num').val();
    var allcounts = phone.length;
    for(i in phone){
        if(phone[i] == maiguo_num){
            counts++;
        }
    }
    alert(Math.floor(counts*100/allcounts*100)/100+'%');
    counts = 0;
}

