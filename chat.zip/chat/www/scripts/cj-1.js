var nametxt = $('.name');
var phonetxt = $('.phone');
var runing = true;
var num = null;
var zd = {"3":"13613040013","5":"13613040015","8":"13613040018"};
var t;
var phone;
//var phone = ["13613040010","13613040011","13613040012","13613040013","13613040014","13613040015","13613040016","13613040017","13613040018","13613040019"];
var pcount;//参加人数
var zd_key;
var count = 1;
var phonenum;
var td;
var counts = 0;

//开始停止
function start(td = null,phonenum = null) {
    if (runing) {
        runing = false;
        startNum();
        $('#sound_play')[0].play();
    } else {
        runing = true;
        stop(td,phonenum);
        show(td,phonenum);
    }
}
//循环参加名单
function startNum() {
	num = Math.floor(Math.random() * (phone.length-1));
    var target = phone[num];
    if (target == undefined) {
        startNum()
    }
    phonetxt.html(target);
    t = setTimeout(startNum, 0);
}
//停止跳动
function stop(td = null,phonenum = null) {
	clearInterval(t);
    t = 0;
	phonetxt.html(phonenum);
}

//打印中奖者名单
function show(td = null,phonenum = null) {
    $('.list').prepend("<p>" + td + " -- " + phonenum + "</p>");
}
function search(){
    var maiguo_num = $('#maiguo_num').val();
    var allcounts = phone.length;
    for(i in phone){
        if(phone[i] == maiguo_num){
            counts++;
        }
    }
    alert(Math.floor(counts*100/allcounts*100)/100+'%');
    counts = 0;
}

