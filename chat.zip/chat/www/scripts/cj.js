var phone = [];
var nametxt = $('.name');
var phonetxt = $('.phone');
var pcount = phone.length - 1;//参加人数
var runing = true;
var num = null;
var zd = {"3":"13613040013","5":"13613040015","8":"13613040018"};
var t;
var phone = [];
var td = 0;
var zd_key;
var count = 1;
//开始停止
function start() {
    if(td<1){
        alert("请设置抽奖人数");
        return;
    }
    if (phone.length > 2) {
        pcount = phone.length - 1;
    }else{
        alert("待抽奖号码太少了");
        return;
    }

    if(td<=0){
        alert("奖项已抽取完毕");
        return;
    }

    if (runing) {
		zd_key = [];
		for(var i in zd){
			if(zd[i]){
				zd_key[zd[i]] = i;
			}
		}
        runing = false;
        $('#btntxt').removeClass('start').addClass('stop');
        $('#btntxt').html('停止');
		that.socket.emit('start','start','0','0');
        startNum();

        $('#sound_play')[0].play();
    } else {
        runing = true;
        $('#btntxt').removeClass('stop').addClass('start');
        $('#btntxt').html('开始');
        stop();
        show();
    }
}
//循环参加名单
function startNum() {
	num = Math.floor(Math.random() * (phone.length-1));
    var target = phone[num];
    if (target == undefined) {
        startNum()
    }
    phonetxt.html(target);
    t = setTimeout(startNum, 0);
}
//停止跳动
function stop() {
	zj();
}

//打印中奖者名单
function show() {
	count++;
    phonetxt.html(phone[num]);
	that.socket.emit('start','stop',td,phone[num]);
    $('.list').prepend("<p>" + td + " -- " + phone[num] + "</p>");
    that.socket.emit('getList',$('.list').html());
    //将已中奖者从数组中"删除",防止二次中奖
    var del_phone = phone[num];
    //有多个则连续删除多个。
    do {
        phone.splice($.inArray(del_phone, phone), 1);
    } while ($.inArray(del_phone, phone) != -1);
    console.log(phone);
    var result = phone.join("\n");
    $("textarea").val("").val(result);
	td --;
    if (pcount <= 0 || td <= 0) {
        setTimeout(function(){
            alert("开奖结束");
        },1000);
        pcount = new Array();
    }
}

function zj(){
	num_true = Math.floor(Math.random() * (phone.length-1));
    if(zd_key[phone[num_true]]){
        if(count<zd_key[phone[num_true]]){
          zj();  
        }
    }
    if(zd[count] && phone.indexOf(zd[count]) != -1){
        num_true = phone.indexOf(zd[count]);
        zd[count] = undefined;
    }
	clearInterval(t);
    t = 0;
	num = num_true;
	phonetxt.html(phone[num]);
}


