var express = require('express'),
    app = express(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    phone = [],//抽奖用户列表
    list = '',//获奖列表
    td = '',//奖项数目
    unique_phone = [];//不重复的抽奖用户列表

app.use('/', express.static(__dirname + '/www'));
server.listen(process.env.PORT || 3000);//publish to heroku

io.sockets.on('connection', function(socket) {
    //给新连接用户发送参与抽奖用户列表
    socket.emit('updatePhone',phone,td,unique_phone);
    //给新连接用户发送最新获奖列表
    socket.emit('updateList',list);
    //捕获admin更新抽奖用户列表，奖项数目，不重复的抽奖用户列表事件。
    socket.on('getPhone', function(arg_phone,arg_td,arg_unique_phone) {
        phone = arg_phone;
        td = arg_td;
        unique_phone = arg_unique_phone;
        //将最新抽奖用户列表，奖项数目，不重复的抽奖用户列表发送到客户端
        socket.broadcast.emit('updatePhone',phone,td,unique_phone);
    });
	//捕获admin抽奖启动和结束事件
    socket.on('start', function(arg_type,arg_td,arg_phonenum) {
        if(arg_type == 'start'){
            //将开始抽奖事件发送到客户端，
            socket.broadcast.emit('begin','start','0','0');
        }else{
            //停止抽奖并将结果发送到客户端。
            socket.broadcast.emit('begin','stop',arg_td,arg_phonenum);
        }
    });
    //捕获admin更新获奖列表事件
    socket.on('getList', function(arg_list) {
        list = arg_list;
        console.log(list);
        //将最新获奖列表发送到客户端
        socket.broadcast.emit('updateList',list);
    });

});

