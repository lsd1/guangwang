var express = require('express'),
    app = express(),
    server = require('http').createServer(app),
    io = require('socket.io').listen(server),
    phone = [],//抽奖用户列表
    list = '',//获奖列表
    td = 0,//奖项数目
    status = 0,//抽奖状态，0为停止，1为进行中。
    lottery_type = 0;//抽奖类型。1：一等奖；2：二等奖；3：三等奖；4：四等奖。
app.use('/', express.static(__dirname + '/www'));
server.listen(process.env.PORT || 3000);//publish to heroku

io.sockets.on('connection', function(socket) {
    //给新连接用户发送参与抽奖用户列表
    socket.emit('updatePhone',phone,td,status,lottery_type);
    //给新连接用户发送最新获奖列表
    socket.emit('updateList',list);
    //捕获admin更新抽奖用户列表，奖项数目，不重复的抽奖用户列表,抽奖状态事件。
    socket.on('getPhone', function(arg_phone,arg_td,arg_status,arg_lottery_type) {
        phone = arg_phone;
        td = arg_td;
        status = arg_status;
        lottery_type = arg_lottery_type;
        //将最新抽奖用户列表，奖项数目，不重复的抽奖用户列表发送到客户端
        socket.broadcast.emit('updatePhone',phone,td,status,lottery_type);
        socket.emit('updatePhone',phone,td,status,lottery_type);//更新当前用户。
    });
	//捕获admin抽奖启动事件
    socket.on('start', function() {
        //将开始抽奖事件发送到客户端。
        socket.broadcast.emit('running',true,td,'0');
        status = 1;//开始
    });
    //捕获admin抽奖结束事件
    socket.on('stop', function(arg_td,arg_phonenum,arg_lottery_type) {
        //停止抽奖并将结果发送到客户端。
        td = arg_td;
        phone.splice(phone.indexOf(arg_phonenum),1);
        socket.broadcast.emit('running',false,td,arg_phonenum,arg_lottery_type);
        td--;
        status = 0;//停止
    });
    //捕获admin更新获奖列表事件
    socket.on('getList', function(arg_list) {
        list = arg_list;
        //将最新获奖列表发送到客户端
        socket.broadcast.emit('updateList',list);
    });

});

