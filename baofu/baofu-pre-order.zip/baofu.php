<?php

error_reporting(0); //抑制所有错误信息
@header("content-Type: text/html; charset=utf-8"); //语言强制

require_once('SdkXML.php');
require_once('BFRSA.php');

$pre_order_url = 'https://vgw.baofoo.com/quickpay/api/prepareorder';
$cfm_order_url = 'https://vgw.baofoo.com/quickpay/api/confirmorder';
$notify_url = 'https://preapi.maiguoer.com/test';

$version = "4.0.0.0";//版本号
$member_id = "100000178";	//商户号
$terminal_id = "100000916";	//终端号
$input_charset = "1";//字符集
$language = "1";//语言
$data_type = "xml";//加密报文的数据类型（xml/json）
$txt_sub_type = '01'; //默认01普通02分账

$private_key_password = "100000178_204500";	//商户私钥证书密码
$pfxfilename = "bfkey_100000178@@100000916.pfx";  //注意证书路径是否存在
$cerfilename = "bfkey_100000178@@100000916.cer";//注意证书路径是否存在

$trans_id = 'test' . date('YmdHis');
$trans_serial_no = 'testpay' . date('YmdHis');
$txn_amt = 1;
$trade_date = date('YmdHis');
$additional_info = '一个大西瓜';
$req_reserved = '保留';
$risk_item = 4001;

$parms = [
	'terminal_id' => $terminal_id, 'member_id' => $member_id, 'user_id' => '100000', 'trans_id' => $trans_id,
	'txn_amt' => $txn_amt, 'trade_date' => $trade_date, 'additional_info' => $additional_info, 
	'notify_url' => $notify_url, 'req_reserved' => $req_reserved, 'trans_serial_no' => $trans_serial_no,
	'risk_item' => $risk_item
];

$toxml = new SdkXML();
$string = $toxml->toXml($parms);

//实例化加密类。
$BFRsa = new BFRSA($pfxfilename, $cerfilename, $private_key_password);

//先BASE64进行编码再RSA加密
$string = $BFRsa->encryptedByPrivateKey($string);	

$data = [
	'version' => $version, 'input_charset' => $input_charset, 'terminal_id' => $terminal_id, 'member_id' => $member_id,
	'data_type' => $data_type, 'txt_sub_type' => $txt_sub_type, 'data_content' => $string
];

echo curl_post($pre_order_url, $data);

function curl_post($url, $data) 
{	 
	//格式化参数
	$body = http_build_query($data);

	// 启动一个CURL会话
	$curl = curl_init(); 
	curl_setopt($curl, CURLOPT_URL, $url); 
	curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
	curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);	
	curl_setopt($curl, CURLOPT_POST, true);
	curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
	curl_setopt($curl, CURLOPT_TIMEOUT, 30);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		
	$tmpInfo = curl_exec($curl);

	if (curl_errno($curl)) {
		$tmpInfo = curl_error($curl);
	}

	curl_close($curl);

	return $tmpInfo;
}


?>
